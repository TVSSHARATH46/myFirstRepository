# Gadgets Page

Given two files `app.js` and `gadgets.html`, write an API in `app.js` file for the path `/gadgets` that sends the `gadgets.html` file as a response.

Export the express instance using default export syntax.

<b>Use Common JS module syntax</b>.
